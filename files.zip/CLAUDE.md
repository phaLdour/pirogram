# CLAUDE.md — Yazılım Geliştirme Şirketi

## Şirket Kimliği

Bu repo, bir yazılım geliştirme şirketinin proje geliştirme altyapısıdır.
Her proje bu yapı üzerinde çalışır. Müşteri projelerinden iç ürünlere kadar
tüm geliştirme süreçleri bu agent team mimarisi ile yönetilir.

**Çalışma Dili:** Türkçe (teknik terimler İngilizce kalabilir)
**Geliştirme Felsefesi:** Kalite > Hız. Her çıktı production-ready olmalı.

---

## Agent Team Yapısı

Bu projede aşağıdaki roller aktiftir. Her rol `.claude/agents/` altında tanımlıdır.
Agentlar birbirleriyle doğrudan mesajlaşır ve paylaşımlı görev listesi üzerinden
koordineli çalışır.

```
┌─────────────────────────────────────────────────┐
│                   CTO / LEAD                    │
│         Mimari kararlar, koordinasyon           │
└─────────────────┬───────────────────────────────┘
                  │
        ┌─────────┴──────────┐
        ▼                    ▼
┌───────────────┐    ┌───────────────┐
│   Product     │    │  UX Designer  │
│   Manager     │    │               │
└───────┬───────┘    └───────┬───────┘
        │                    │
        └──────────┬─────────┘
                   ▼
        ┌──────────────────────┐
        │  Frontend Developer  │
        │  Backend Developer   │  ← paralel çalışır
        │  DevOps Engineer     │
        └──────────┬───────────┘
                   ▼
        ┌──────────────────────┐
        │  Code Reviewer       │
        │  QA Lead             │  ← paralel çalışır
        │  Security Engineer   │
        └──────────────────────┘
```

### Roller ve Sorumluluklar

| Agent            | Dosya                    | Model              | Birincil Görev                         |
|------------------|--------------------------|--------------------|----------------------------------------|
| cto              | agents/cto.md            | claude-opus-4-6    | Mimari, koordinasyon, teknik karar     |
| product-manager  | agents/product-manager.md| claude-sonnet-4-6  | Gereksinim, user story, önceliklendirme|
| ux-designer      | agents/ux-designer.md    | claude-sonnet-4-6  | UI/UX tasarım kararları, bileşen spec  |
| frontend-dev     | agents/frontend-dev.md   | claude-sonnet-4-6  | React/Next.js, bileşenler, sayfalar    |
| backend-dev      | agents/backend-dev.md    | claude-sonnet-4-6  | API, veritabanı, servisler             |
| devops           | agents/devops.md         | claude-sonnet-4-6  | CI/CD, deployment, altyapı             |
| code-reviewer    | agents/code-reviewer.md  | claude-opus-4-6    | Kod kalitesi, standartlar, PR review   |
| qa-lead          | agents/qa-lead.md        | claude-sonnet-4-6  | Test stratejisi, test yazımı, bug takip|
| security         | agents/security.md       | claude-opus-4-6    | Güvenlik denetimi, zafiyet tespiti     |

---

## Geliştirme İş Akışı

Her yeni özellik veya proje şu aşamalardan geçer. Agentlar bu sırayla devreye girer:

### Aşama 1 — Tanımlama
```
Sen (kullanıcı) → CTO'ya görevi ver
CTO → Product Manager'a gereksinim analizi yaptırır
Product Manager → user story ve kabul kriterleri yazar
```

### Aşama 2 — Tasarım
```
CTO → UX Designer'a bileşen spec yaptırır
UX Designer → Frontend Dev'e tasarım kararlarını iletir
UX Designer + Product Manager → öncelikleri netleştirir
```

### Aşama 3 — Geliştirme (Paralel)
```
Frontend Dev → UI bileşenleri yazar
Backend Dev  → API ve veritabanı katmanını yazar
DevOps       → gerekirse altyapı/CI hazırlar
(üçü aynı anda çalışabilir — bağımsız modüllerde)
```

### Aşama 4 — Kalite (Paralel)
```
Code Reviewer → kodu inceler, standart kontrol
QA Lead       → testleri yazar ve çalıştırır
Security      → güvenlik açığı tarar
(üçü aynı anda çalışabilir)
```

### Aşama 5 — Çıktı
```
CTO → raporları toplar, son kararı verir
Sen (kullanıcı) → PR'ı inceler, merge eder
```

---

## Agent İletişim Protokolü

Agentlar birbirlerine mesaj gönderirken şu formatı kullanır:

```
[ALICI_AGENT'A]: Kısa başlık
Durum: tamamlandı / devam ediyor / engel var
Çıktı: [ne üretildi]
Bağımlılık: [bir sonraki aşama için ne gerekiyor]
Soru: [varsa, diğer agentin cevaplaması gereken]
```

Örnek:
```
[FRONTEND-DEV'E]: Kullanıcı profil bileşeni hazır
Durum: tamamlandı
Çıktı: UserProfile.tsx, useUserData.ts hook'u
Bağımlılık: /api/user/:id endpoint'i (backend-dev'de)
Soru: Avatar upload için Cloudinary mı yoksa S3 mi kullanıyoruz?
```

---

## Tech Stack Standartları

Yeni bir proje başlarken CTO bu stack'i temel alır. Değişiklik için CTO onayı gerekir.

| Katman       | Varsayılan Teknoloji                 |
|--------------|--------------------------------------|
| Framework    | Next.js 15 (App Router)              |
| Dil          | TypeScript strict                    |
| Stil         | Tailwind CSS v4                      |
| Veritabanı   | PostgreSQL + Prisma ORM              |
| Cache        | Redis (Upstash)                      |
| Auth         | NextAuth.js v5                       |
| Test         | Jest + RTL + Playwright              |
| CI/CD        | GitHub Actions + Vercel              |
| Monitoring   | Sentry (hata) + Vercel Analytics     |

---

## Evrensel Kod Kuralları

Tüm agentlar bu kurallara uymak zorunda:

- TypeScript `any` yasak — `unknown` veya tip tanımı kullan
- Her fonksiyon için JSDoc yorum (ne yapar, parametreler, dönüş)
- Her API endpoint'te hata yönetimi zorunlu
- `console.log` production koda giremez — logger kullan
- Hardcode değer yasak — constants dosyasına al
- Sırlar (API key, şifre) `.env` dışında hiçbir yerde geçmez
- Her PR açıklaması: ne değişti, neden, nasıl test edildi

---

## Kalite Kapıları (Quality Gates)

Kod merge edilmeden önce şu kontroller geçilmeli:

- [ ] TypeScript hatasız derliyor (`tsc --noEmit`)
- [ ] Lint hatasız (`eslint .`)
- [ ] Tüm testler geçiyor (`npm test`)
- [ ] Code Reviewer onayı verildi
- [ ] QA Lead test senaryolarını tamamladı
- [ ] Security taraması temiz çıktı (kritik değişikliklerde)

---

## Agent Team Başlatma Komutları

### Yeni Özellik Geliştirme
```
CTO'ya şunu söyle:

[YENİ ÖZELLİK]: [özellik adı]
[AÇIKLAMA]: [ne yapması lazım, 2-3 cümle]
[ÖNCELİK]: yüksek / orta / düşük
[SON TARİH]: varsa
[KISITLAR]: varsa özel gereksinimler

Tam agent team workflow'unu başlat.
```

### Hata Düzeltme
```
CTO'ya şunu söyle:

[HATA]: [hatanın kısa açıklaması]
[NEREDE]: [hangi sayfa/özellik/API]
[ADIMLAR]: [nasıl tekrarlanır]
[BEKLENEN]: [olması gereken davranış]

QA ve Backend/Frontend'i devreye al.
```

### Güvenlik Denetimi
```
CTO'ya şunu söyle:

[GÜVENLİK DENETİMİ]: [kapsam - tüm proje veya belirli modül]
Security agent'ı plan onayı ile çalıştır.
Sonuçları raporla, kritik bulgular için anında bildir.
```

---

## Performans Hedefleri (Tüm Projeler)

- Lighthouse skoru: 90+ (Performance, Accessibility, Best Practices, SEO)
- LCP < 2.5s, FID < 100ms, CLS < 0.1
- API yanıt süresi: < 200ms (p95)
- Test coverage: > 80%
- Zero critical security vulnerabilities

---

## Önemli Notlar

- Agentlar bağımsız modüllerde paralel çalışabilir ama aynı dosyayı aynı anda düzenleyemez
- CTO tüm mimari kararların son onay merciidir
- Her agent kendi alanı dışına çıkmadan önce CTO'ya danışır
- Plan onayı gerektiren görevler: mimari değişiklik, güvenlik, veritabanı şema değişikliği
- Agentlar idle kalınca otomatik kapanır — CTO gerektiğinde yeniden başlatır
